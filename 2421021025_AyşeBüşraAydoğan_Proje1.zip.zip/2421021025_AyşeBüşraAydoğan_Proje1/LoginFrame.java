/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package com.mycompany.aysebusraaydoganproje;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;
import javax.swing.JOptionPane;


/**
 *
 * @author Huawei
 */
public class LoginFrame extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(LoginFrame.class.getName());

    public LoginFrame() {
       initComponents();
    this.setSize(450, 500); // Genişlik: 450, Yükseklik: 500
    this.setLocationRelativeTo(null);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
        java.awt.GridBagConstraints gridBagConstraints;

        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        txtLoginEmail = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        txtLoginPassword = new javax.swing.JPasswordField();
        btnLogin = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        txtRegName = new javax.swing.JTextField();
        txtRegEmail = new javax.swing.JTextField();
        txtRegSurname = new javax.swing.JTextField();
        txtRegPassword = new javax.swing.JPasswordField();
        txtRegPasswordConfirm = new javax.swing.JPasswordField();
        btnRegister = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jTabbedPane1.setBackground(new java.awt.Color(255, 255, 255));

        jPanel1.setBackground(new java.awt.Color(153, 255, 255));
        jPanel1.setLayout(new java.awt.GridBagLayout());

        jLabel1.setText("E-Posta:");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.gridwidth = 2;
        gridBagConstraints.ipadx = 26;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.insets = new java.awt.Insets(62, 68, 0, 0);
        jPanel1.add(jLabel1, gridBagConstraints);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 2;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.gridwidth = 2;
        gridBagConstraints.gridheight = 2;
        gridBagConstraints.ipadx = 124;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.insets = new java.awt.Insets(59, 32, 0, 243);
        jPanel1.add(txtLoginEmail, gridBagConstraints);

        jLabel2.setText("Şifre:");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.ipadx = 19;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.insets = new java.awt.Insets(45, 68, 0, 0);
        jPanel1.add(jLabel2, gridBagConstraints);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 2;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.gridwidth = 2;
        gridBagConstraints.gridheight = 2;
        gridBagConstraints.ipadx = 124;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.insets = new java.awt.Insets(42, 32, 0, 243);
        jPanel1.add(txtLoginPassword, gridBagConstraints);

        btnLogin.setText("Giriş Yap");
        btnLogin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLoginActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 2;
        gridBagConstraints.gridy = 4;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.insets = new java.awt.Insets(58, 32, 166, 0);
        jPanel1.add(btnLogin, gridBagConstraints);

        jTabbedPane1.addTab("Giriş Yap", jPanel1);

        jPanel2.setBackground(new java.awt.Color(153, 255, 255));
        jPanel2.setLayout(new java.awt.GridBagLayout());

        jLabel3.setText("E-Posta:");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 4;
        gridBagConstraints.gridwidth = 3;
        gridBagConstraints.ipadx = 51;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.insets = new java.awt.Insets(21, 71, 0, 0);
        jPanel2.add(jLabel3, gridBagConstraints);

        jLabel4.setText("Ad:");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.ipadx = 19;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.insets = new java.awt.Insets(44, 71, 0, 0);
        jPanel2.add(jLabel4, gridBagConstraints);

        jLabel5.setText("Soyad:");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.ipadx = 2;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.insets = new java.awt.Insets(24, 71, 0, 0);
        jPanel2.add(jLabel5, gridBagConstraints);

        jLabel6.setText("Şifre:");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 6;
        gridBagConstraints.ipadx = 11;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.insets = new java.awt.Insets(21, 71, 0, 0);
        jPanel2.add(jLabel6, gridBagConstraints);

        jLabel7.setText("Şifre Tekrar:");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 8;
        gridBagConstraints.gridwidth = 2;
        gridBagConstraints.ipadx = 17;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.insets = new java.awt.Insets(21, 71, 0, 0);
        jPanel2.add(jLabel7, gridBagConstraints);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 3;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.gridwidth = 2;
        gridBagConstraints.gridheight = 2;
        gridBagConstraints.ipadx = 126;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.insets = new java.awt.Insets(41, 32, 0, 213);
        jPanel2.add(txtRegName, gridBagConstraints);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 3;
        gridBagConstraints.gridy = 4;
        gridBagConstraints.gridwidth = 2;
        gridBagConstraints.gridheight = 2;
        gridBagConstraints.ipadx = 126;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.insets = new java.awt.Insets(18, 32, 0, 213);
        jPanel2.add(txtRegEmail, gridBagConstraints);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 3;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.gridwidth = 2;
        gridBagConstraints.gridheight = 2;
        gridBagConstraints.ipadx = 126;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.insets = new java.awt.Insets(21, 32, 0, 213);
        jPanel2.add(txtRegSurname, gridBagConstraints);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 3;
        gridBagConstraints.gridy = 6;
        gridBagConstraints.gridwidth = 2;
        gridBagConstraints.gridheight = 2;
        gridBagConstraints.ipadx = 126;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.insets = new java.awt.Insets(18, 32, 0, 213);
        jPanel2.add(txtRegPassword, gridBagConstraints);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 3;
        gridBagConstraints.gridy = 8;
        gridBagConstraints.gridwidth = 2;
        gridBagConstraints.gridheight = 2;
        gridBagConstraints.ipadx = 126;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.insets = new java.awt.Insets(18, 32, 0, 213);
        jPanel2.add(txtRegPasswordConfirm, gridBagConstraints);

        btnRegister.setText("Kayıt Ol");
        btnRegister.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRegisterActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 3;
        gridBagConstraints.gridy = 10;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.insets = new java.awt.Insets(43, 10, 100, 0);
        jPanel2.add(btnRegister, gridBagConstraints);

        jTabbedPane1.addTab("Kayıt Ol", jPanel2);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane1)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane1)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnRegisterActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRegisterActionPerformed

    String email = txtRegEmail.getText();
    String ad = txtRegName.getText();
    String soyad = txtRegSurname.getText();
    String sifre = new String(txtRegPassword.getPassword());
    String sifreTekrar = new String(txtRegPasswordConfirm.getPassword());
    
    if (email.contains(";") || ad.contains(";") || soyad.contains(";")) {
    JOptionPane.showMessageDialog(this, "Lütfen e-postada';' karakterini kullanmayın!");
    return;
}
    if (!email.contains("@") || !email.contains(".")) {
    JOptionPane.showMessageDialog(this, "Geçerli bir e-posta formatı giriniz!");
    return;
}

    //Boş alan kontrolü yapar
    if (email.isEmpty() || ad.isEmpty() || soyad.isEmpty() || sifre.isEmpty()) {
        JOptionPane.showMessageDialog(this, "Lütfen tüm alanları doldurun!");
        return;
    }

    //Şifre uzunluğu ve eşleşme kontrolü yapar
    if (sifre.length() < 6) {
        JOptionPane.showMessageDialog(this, "Şifre en az 6 karakter olmalıdır!");
        return;
    }
    if (!sifre.equals(sifreTekrar)) {
        JOptionPane.showMessageDialog(this, "Şifreler birbiriyle uyuşmuyor!");
        return;
    }

    //E-posta kontrolü yapar ve dosyaya yazar
    try {
        File file = new File("users.txt");
        //Dosya yoksa başlık satırıyla beraber oluşturur
        if (!file.exists()) {
            PrintWriter writer = new PrintWriter(file);
            writer.println("email;ad;soyad;sifre;enYuksekSkor");
            writer.close();
        }

        // E-posta kayıtlı mı kontrol eder
        Scanner scanner = new Scanner(file);
        while (scanner.hasNextLine()) {
            String line = scanner.nextLine();
            if (line.startsWith(email + ";")) {
                JOptionPane.showMessageDialog(this, "Bu e-posta adresi zaten kayıtlı, lütfen giriş yapınız!");
                scanner.close();
                return;
            }
        }
        scanner.close();

        //Dosyaya ekler
        FileWriter fw = new FileWriter(file, true);
        BufferedWriter bw = new BufferedWriter(fw);
        // Format: email;ad;soyad;sifre;skor
        bw.write(email + ";" + ad + ";" + soyad + ";" + sifre + ";0.0");
        bw.newLine();
        bw.close();

        JOptionPane.showMessageDialog(this, "Kayıt başarıyla tamamlandı! Giriş yapabilirsiniz.");
        
    } catch (IOException e) {
        JOptionPane.showMessageDialog(this, "Dosya hatası: " + e.getMessage());
    }
    }//GEN-LAST:event_btnRegisterActionPerformed

    private void btnLoginActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLoginActionPerformed
    String email = txtLoginEmail.getText();
    String sifre = new String(txtLoginPassword.getPassword());

    try {
        File file = new File("users.txt");
        if (!file.exists()) {
            JOptionPane.showMessageDialog(this, "Henüz hiçbir kullanıcı kayıtlı değil!");
            return;
        }

        Scanner scanner = new Scanner(file);
        boolean girisBasarili = false;
        String kullaniciAdi = "";

        while (scanner.hasNextLine()) {
            String line = scanner.nextLine();
            String[] parca = line.split(";"); // email;ad;soyad;sifre;skor

            if (parca[0].equals(email) && parca[3].equals(sifre)) {
                girisBasarili = true;
                kullaniciAdi = parca[1] + " " + parca[2]; // Ad + Soyad
                break;
            }
        }
        scanner.close();

        if (girisBasarili) {
           GameFrame oyunEkrani = new GameFrame();
    
    oyunEkrani.setWelcomeMessage(kullaniciAdi, email); 
    
    oyunEkrani.setVisible(true);
    this.dispose();
    
    } else {
        JOptionPane.showMessageDialog(this, "E-posta veya şifre hatalı!");
    }

} catch (Exception e) { 
    JOptionPane.showMessageDialog(this, "Bir hata oluştu: " + e.getMessage());
} 
        
    }//GEN-LAST:event_btnLoginActionPerformed
 
    public static void main(String args[]) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        java.awt.EventQueue.invokeLater(() -> new LoginFrame().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnLogin;
    private javax.swing.JButton btnRegister;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JTextField txtLoginEmail;
    private javax.swing.JPasswordField txtLoginPassword;
    private javax.swing.JTextField txtRegEmail;
    private javax.swing.JTextField txtRegName;
    private javax.swing.JPasswordField txtRegPassword;
    private javax.swing.JPasswordField txtRegPasswordConfirm;
    private javax.swing.JTextField txtRegSurname;
    // End of variables declaration//GEN-END:variables
}
