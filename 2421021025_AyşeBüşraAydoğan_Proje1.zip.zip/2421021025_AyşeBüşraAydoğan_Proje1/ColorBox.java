/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.aysebusraaydoganproje;
import javax.swing.*;
import javax.swing.border.LineBorder;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class ColorBox extends JPanel {
    private Color boxColor;
    private boolean isFocused = false;

    public ColorBox(Color color, int x, int y) {
        this.boxColor = color;
        this.setBackground(color);
        // Kutular 50x50 olmalı 
        this.setBounds(x, y, 50, 50); 
        this.setBorder(new LineBorder(Color.BLACK, 1));

        this.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                // Tıklandığında odaklanacak
            }
        });
    }

    public Color getColor() { return boxColor; }
    
    public void setFocus(boolean focused) {
        this.isFocused = focused;
        this.setBorder(new LineBorder(focused ? Color.YELLOW : Color.BLACK, focused ? 3 : 1));
    }
}