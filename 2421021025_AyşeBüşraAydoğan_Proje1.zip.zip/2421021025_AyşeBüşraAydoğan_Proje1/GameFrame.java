
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */

package com.mycompany.aysebusraaydoganproje;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Random;
import java.awt.Rectangle;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import javax.swing.JOptionPane;

/**
 *
 * @author Huawei
 */
public class GameFrame extends javax.swing.JFrame {
    
    private long startTime; // Oyun başlangıç zamanını tutar 
    private ArrayList<ColorBox> boxes = new ArrayList<>(); // Kutuları tutar
    private ColorBox selectedBox = null;
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(GameFrame.class.getName());
    private String currentUserEmail;
    private void moveSelectedBox(int dx, int dy) {
    // Sadece bir kutu seçiliyse hareket eder
    if (selectedBox != null) {
        int currentX = selectedBox.getX();
        int currentY = selectedBox.getY();
        
        // Yeni konumu hesapla
        int newX = currentX + dx;
        int newY = currentY + dy;
        
        // Kutuyu taşı
        selectedBox.setLocation(newX, newY);
        
        // Her hareketten sonra eşleşme kontrolü yapar
        checkCollision(); 
    }
}
    
    private void checkCollision() {
    if (selectedBox == null) return;

    // Seçili kutunun sınırlarını alır
    Rectangle r1 = selectedBox.getBounds();

    // Listedeki diğer tüm kutuları tek tek kontrol eder
    for (int i = 0; i < boxes.size(); i++) {
        ColorBox otherBox = boxes.get(i);

        
        if (otherBox == selectedBox) continue;

        // Diğer kutunun sınırlarını alır 
        Rectangle r2 = otherBox.getBounds();

        // 1. Çarpışma var mı diye kontrol eder
        // 2. Renkleri aynı mı diye kontrol eder 
        if (r1.intersects(r2) && selectedBox.getColor().equals(otherBox.getColor())) {
            
            
            
            // Eşlenen kutuları siler
            gamePanel.remove(selectedBox);
            gamePanel.remove(otherBox);

            // Kutuları ArrayList'ten siler
           
            boxes.remove(selectedBox);
            boxes.remove(otherBox);

            // Seçili kutuyu sıfırlar
            selectedBox = null;

            // Paneli görsel olarak günceller 
            gamePanel.revalidate();
            gamePanel.repaint();

            // Oyunun bitip bitmediğini kontrol eder
            checkGameFinished();

            // Bir eşleşme bulduğunda döngüden çıkar
            break; 
        }
    }
}
    private void checkGameFinished() {
    if (boxes.isEmpty()) {
        // Oyun bittiğinde süreyi durdurur 
        long endTime = System.currentTimeMillis();
        double actualTime = (endTime - startTime) / 1000.0; 

        // Skor hesaplama: actualTime * (5 / numberOfPairs) 
        int pairCount = (Integer) jSpinner1.getValue();
        double normalizedScore = actualTime * (5.0 / pairCount); 

        double currentBest = getBestScore();

        // 2. Yeni skor daha iyiyse VEYA henüz rekoru yoksa (0.0 ise) sorar
        if (normalizedScore < currentBest || currentBest == 0.0) {
            
            String message = "TEBRİKLER! Yeni Rekor: " + String.format("%.2f", normalizedScore) + 
                             "\nBu rekoru kaydetmek ister misiniz?";
            
            int secim = JOptionPane.showConfirmDialog(this, message, "Rekor Kırıldı!", JOptionPane.YES_NO_OPTION);

            if (secim == JOptionPane.YES_OPTION) {
                saveHighScore(normalizedScore);
            }
            
        } else {
            // Rekor kırılamadıysa sadece bilgi mesajı gösterir
            String message = "Oyun bitti. Skorunuz: " + String.format("%.2f", normalizedScore) + 
                 "\nMevcut rekorunuzu geçemediniz! \nMevcut rekorunuz: (" + String.format("%.2f", currentBest) + ")";
            
            JOptionPane.showMessageDialog(this, message);
        }
    }
    }
    public void setWelcomeMessage(String adSoyad, String email) {
    lblWelcome.setText("Hoş geldin, " + adSoyad);
    this.currentUserEmail = email; 
}
    
    public GameFrame() {
        initComponents();
        getContentPane().setLayout(new java.awt.BorderLayout());
getContentPane().add(upperPanel, java.awt.BorderLayout.NORTH);
getContentPane().add(gamePanel, java.awt.BorderLayout.CENTER);
        this.setSize(800, 600); // Pencereyi 800x600 boyutuna ayarlar
    this.setLocationRelativeTo(null); // Pencereyi ekranın ortasında açar
        this.addKeyListener(new java.awt.event.KeyAdapter() {
    @Override
    public void keyPressed(java.awt.event.KeyEvent e) {
        int keyCode = e.getKeyCode();
        
        switch (keyCode) {
            case java.awt.event.KeyEvent.VK_UP:
                moveSelectedBox(0, -20);
                break;
            case java.awt.event.KeyEvent.VK_DOWN:
                moveSelectedBox(0, 20);
                break;
            case java.awt.event.KeyEvent.VK_LEFT:
                moveSelectedBox(-20, 0);
                break;
            case java.awt.event.KeyEvent.VK_RIGHT:
                moveSelectedBox(20, 0);
                break;
        }
    }
});
this.setFocusable(true);
        this.setFocusable(true);
    }

  
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        upperPanel = new javax.swing.JPanel();
        jSpinner1 = new javax.swing.JSpinner();
        startButton = new javax.swing.JButton();
        rightBtn = new javax.swing.JButton();
        upperBtn = new javax.swing.JButton();
        leftBtn = new javax.swing.JButton();
        lowerBtn = new javax.swing.JButton();
        lblWelcome = new javax.swing.JLabel();
        gamePanel = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        upperPanel.setBackground(new java.awt.Color(0, 204, 204));

        jSpinner1.setModel(new javax.swing.SpinnerNumberModel(5, 5, 10, 1));

        startButton.setText("Başla");
        startButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                startButtonActionPerformed(evt);
            }
        });

        rightBtn.setText("Sağ");
        rightBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rightBtnActionPerformed(evt);
            }
        });

        upperBtn.setText("Yukarı");
        upperBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                upperBtnActionPerformed(evt);
            }
        });

        leftBtn.setText("Sol");
        leftBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                leftBtnActionPerformed(evt);
            }
        });

        lowerBtn.setText("Aşağı");
        lowerBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                lowerBtnActionPerformed(evt);
            }
        });

        lblWelcome.setFont(new java.awt.Font("STZhongsong", 1, 18)); // NOI18N
        lblWelcome.setForeground(new java.awt.Color(255, 255, 255));
        lblWelcome.setText("Hoşgeldiniz!");

        javax.swing.GroupLayout upperPanelLayout = new javax.swing.GroupLayout(upperPanel);
        upperPanel.setLayout(upperPanelLayout);
        upperPanelLayout.setHorizontalGroup(
            upperPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(upperPanelLayout.createSequentialGroup()
                .addContainerGap(628, Short.MAX_VALUE)
                .addComponent(lowerBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 63, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(99, 99, 99))
            .addGroup(upperPanelLayout.createSequentialGroup()
                .addGap(33, 33, 33)
                .addGroup(upperPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(upperPanelLayout.createSequentialGroup()
                        .addComponent(jSpinner1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(startButton))
                    .addComponent(lblWelcome, javax.swing.GroupLayout.PREFERRED_SIZE, 364, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(upperPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, upperPanelLayout.createSequentialGroup()
                        .addComponent(leftBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 63, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(58, 58, 58)
                        .addComponent(rightBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 63, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(39, 39, 39))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, upperPanelLayout.createSequentialGroup()
                        .addComponent(upperBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 63, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(101, 101, 101))))
        );
        upperPanelLayout.setVerticalGroup(
            upperPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(upperPanelLayout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(lblWelcome)
                .addGap(18, 18, 18)
                .addGroup(upperPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(startButton, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jSpinner1, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, upperPanelLayout.createSequentialGroup()
                .addContainerGap(20, Short.MAX_VALUE)
                .addComponent(upperBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(upperPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(rightBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(leftBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lowerBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(21, 21, 21))
        );

        getContentPane().add(upperPanel);
        upperPanel.setBounds(0, 0, 790, 140);

        gamePanel.setBackground(new java.awt.Color(255, 255, 255));
        gamePanel.setMinimumSize(new java.awt.Dimension(600, 400));
        gamePanel.setPreferredSize(new java.awt.Dimension(600, 400));
        gamePanel.setLayout(null);
        getContentPane().add(gamePanel);
        gamePanel.setBounds(0, 120, 790, 400);
        gamePanel.getAccessibleContext().setAccessibleName("");

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void startButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_startButtonActionPerformed
       gamePanel.removeAll();
    this.startTime = System.currentTimeMillis();
    boxes.clear(); 

    // Sayıyı alır (JSpinner'dan çift sayısını okur)
    int ciftSayisi = (Integer) jSpinner1.getValue();
    
    int kutuBoyutu = 50; 
    
    // Rengi ve kutuyu oluşturur
    for (int i = 0; i < ciftSayisi; i++) {
        // Her çift için rastgele bir renk üretir
        Color rastgeleRenk = new Color((int)(Math.random() * 0x1000000));
        
        // Her renkten 2 kutu oluşturur
        for (int j = 0; j < 2; j++) {
            int rx = 0;
            int ry = 0;
            boolean cakisiyorMu;
            
            // Çakışma olmadığından emin olana kadar yeni koordinat üretir
            do {
                cakisiyorMu = false;
                
                // Koordinatları oyun alanı sınırları içinde rastgele belirler
                rx = (int) (Math.random() * (gamePanel.getWidth() - kutuBoyutu)); 
                ry = (int) (Math.random() * (gamePanel.getHeight() - kutuBoyutu));
                
                // Yeni kutunun kaplayacağı hayali alanı oluşturur
                Rectangle yeniKutuAlani = new Rectangle(rx, ry, kutuBoyutu, kutuBoyutu);
                
                // Listedeki mevcut kutularla çarpışma kontrolü yapar
                for (ColorBox mevcutKutu : boxes) {
                    Rectangle mevcutKutuAlani = mevcutKutu.getBounds();
                    
                    if (yeniKutuAlani.intersects(mevcutKutuAlani)) {
                        cakisiyorMu = true; 
                        break; 
                    }
                }
            } while (cakisiyorMu); 
            
            ColorBox yeniKutu = new ColorBox(rastgeleRenk, rx, ry);
            
            yeniKutu.addMouseListener(new java.awt.event.MouseAdapter() {
                @Override
                public void mouseClicked(java.awt.event.MouseEvent e) {
                    // Eğer önceden seçili bir kutu varsa onun odağını kaldırır
                    if (selectedBox != null) {
                        selectedBox.setFocus(false);
                    }
                    // Yeni kutuyu seçer ve odağını görselleştirir
                    selectedBox = (ColorBox) e.getSource();
                    selectedBox.setFocus(true);
                    
                    // Klavye tuşlarını yakalayabilmek için odağı panele verir
                    GameFrame.this.requestFocus(); 
                }
            });
            
            // Kutuyu hem listeye hem panele ekler
            boxes.add(yeniKutu);
            gamePanel.add(yeniKutu);
        }
    }
    
    // Görseli günceller
    gamePanel.revalidate();
    gamePanel.repaint();
    
    // Oyun başlama zamanını kaydeder
    this.startTime = System.currentTimeMillis(); 
    }//GEN-LAST:event_startButtonActionPerformed

    private void upperBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_upperBtnActionPerformed
       moveSelectedBox(0, -20);
       this.requestFocus();
    }//GEN-LAST:event_upperBtnActionPerformed

    private void lowerBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_lowerBtnActionPerformed
        moveSelectedBox(0, 20);
        this.requestFocus();
    }//GEN-LAST:event_lowerBtnActionPerformed

    private void leftBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_leftBtnActionPerformed
       moveSelectedBox(-20, 0);
       this.requestFocus();
    }//GEN-LAST:event_leftBtnActionPerformed

    private void rightBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rightBtnActionPerformed
        moveSelectedBox(20, 0);
        this.requestFocus();
    }//GEN-LAST:event_rightBtnActionPerformed

    
    public static void main(String args[]) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
       
GameFrame frame = new GameFrame();
frame.setVisible(true);
        java.awt.EventQueue.invokeLater(() -> new GameFrame().setVisible(true));
    }
    private void saveHighScore(double newScore) {
    File inputFile = new File("users.txt");
    File tempFile = new File("users_temp.txt");

    try (BufferedReader reader = new BufferedReader(new FileReader(inputFile));
         BufferedWriter writer = new BufferedWriter(new FileWriter(tempFile))) {

        String line;
        while ((line = reader.readLine()) != null) {
            String[] parts = line.split(";");
            
            if (parts[0].equals(currentUserEmail)) {
                double oldScore = Double.parseDouble(parts[4].replace(",", "."));
                
                 // Sadece yeni skor daha iyiyse satırı günceller
                if (newScore < oldScore || oldScore == 0.0) {
                    line = parts[0] + ";" + parts[1] + ";" + parts[2] + ";" + parts[3] + ";" + String.format("%.2f", newScore);
                } else {
                    JOptionPane.showMessageDialog(this, "Bu skor mevcut rekorunuzdan daha iyi değil.");
                }
            }
            writer.write(line);
            writer.newLine();
        }
    } catch (IOException e) {
        JOptionPane.showMessageDialog(this, "Hata: " + e.getMessage());
    }

    if (inputFile.delete()) {
        tempFile.renameTo(inputFile);
    }
}
   private double getBestScore() {
    try (BufferedReader reader = new BufferedReader(new FileReader("users.txt"))) {
        String line;
        while ((line = reader.readLine()) != null) {
            String[] parts = line.split(";");
            if (parts[0].equals(currentUserEmail)) {
                return Double.parseDouble(parts[4].replace(",", "."));
            }
        }
    } catch (Exception e) {
        return 0.0; // Dosya yoksa veya hata varsa 0 döner
    }
    return 0.0;
}
    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel gamePanel;
    private javax.swing.JSpinner jSpinner1;
    private javax.swing.JLabel lblWelcome;
    private javax.swing.JButton leftBtn;
    private javax.swing.JButton lowerBtn;
    private javax.swing.JButton rightBtn;
    private javax.swing.JButton startButton;
    private javax.swing.JButton upperBtn;
    private javax.swing.JPanel upperPanel;
    // End of variables declaration//GEN-END:variables
}
